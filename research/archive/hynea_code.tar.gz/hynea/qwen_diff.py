"""Differentiable view of the evaluator's Qwen2.5-VL feature reading (image_metrics_utils.Qwen25VLAnalyzer).

The evaluator asks for one strict JSON with every public feature and takes the greedy generation. We teacher-force the
JSON of the REAL reading (Qwen(real photo)) behind the GENERATED image and read, per feature, the log-probability of the
real value. Minimising it for a feature pushes the generated reading of that feature away from the real one (= a
feature mismatch = what the evaluator calls a failure). `pixels()` replicates the HF Qwen2-VL patch layout so the pixel
tensor can carry gradients back to the generator.
"""
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional

import torch
import torch.nn.functional as F

TRACK_A = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(TRACK_A))
from image_metrics_utils import Qwen25VLAnalyzer  # noqa: E402


def eval_prompt(vocabulary: Dict[str, set]) -> str:
    schema = {key: sorted(str(v) for v in values) for key, values in vocabulary.items()}
    return (
        "Inspect this in-car image and classify every requested scene feature. "
        "Return exactly one allowed value for each feature as strict JSON only. "
        "Use UNKNOWN only when a feature cannot be determined. "
        f"Allowed values: {json.dumps(schema, ensure_ascii=True)}"
    )


def value_spans(answer: str) -> Dict[str, tuple]:
    """key -> (char_start, char_end) of the JSON value text inside the raw answer (inside the quotes for strings)."""
    text = answer.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        return {}, text
    dec, spans, pos = json.JSONDecoder(), {}, 0
    for k in obj:
        i = text.find(json.dumps(k, ensure_ascii=True), pos)
        if i < 0:
            continue
        j = text.find(":", i) + 1
        while text[j] in " \n\t":
            j += 1
        _, end = dec.raw_decode(text, j)
        if text[j] == "[":  # ["NO"] -> only the string inside
            a, b = text.find('"', j, end), text.rfind('"', j, end)
            spans[k] = (a + 1, b) if 0 <= a < b else (j, end)
        else:
            spans[k] = (j + 1, end - 1) if text[j] == '"' else (j, end)
        pos = end
    return spans, text


class DiffQwen:
    def __init__(self, device="cuda", analyzer: Optional[Qwen25VLAnalyzer] = None):
        self.an = analyzer or Qwen25VLAnalyzer(device=device)
        self.model, self.proc, self.device = self.an.model, self.an.processor, torch.device(device)
        self.model.requires_grad_(False)
        ip = self.proc.image_processor
        self.mean = torch.tensor(ip.image_mean, device=self.device).view(3, 1, 1)
        self.std = torch.tensor(ip.image_std, device=self.device).view(3, 1, 1)
        self.ps, self.tps, self.merge = ip.patch_size, ip.temporal_patch_size, ip.merge_size

    def read(self, pil, vocabulary):
        """Evaluator-style reading (greedy generation); switches off train-mode/checkpointing for the generation."""
        was = self.model.training
        self.model.eval()
        try:
            return self.an.classify_features(pil, vocabulary)
        finally:
            self.model.train(was)

    def grid_for(self, pil):
        out = self.proc(text=["x"], images=[pil], return_tensors="pt")
        return out["image_grid_thw"][0].tolist(), out["pixel_values"]

    def pixels(self, img01: torch.Tensor, hw) -> torch.Tensor:
        """img01: (3,h,w) in [0,1] with grad -> (gh*gw, 3*tps*ps*ps) patches at size hw (multiples of 28)."""
        H, W = hw
        x = F.interpolate(img01[None], size=(H, W), mode="bicubic", align_corners=False)[0].clamp(0, 1)
        x = ((x - self.mean) / self.std)[None].repeat(self.tps, 1, 1, 1)  # (T,3,H,W)
        gh, gw, m, p = H // self.ps, W // self.ps, self.merge, self.ps
        x = x.reshape(1, self.tps, 3, gh // m, m, p, gw // m, m, p).permute(0, 3, 6, 4, 7, 2, 1, 5, 8)
        return x.reshape(gh * gw, 3 * self.tps * p * p)

    def build_teacher(self, vocabulary, real_answer: str, dummy_pil):
        """Tokenised (prefix + real answer) and per-key token index lists of the answer."""
        prompt = eval_prompt(vocabulary)
        msgs = [{"role": "user", "content": [{"type": "image", "image": dummy_pil}, {"type": "text", "text": prompt}]}]
        prefix = self.proc.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        spans, text = value_spans(real_answer)
        if not spans:
            return None
        pre = self.proc(text=[prefix], images=[dummy_pil], return_tensors="pt")
        tok = self.proc.tokenizer(text + "<|im_end|>", add_special_tokens=False, return_offsets_mapping=True)
        ids = torch.cat([pre["input_ids"][0], torch.tensor(tok["input_ids"])])[None]
        n0 = pre["input_ids"].shape[1]
        key_tokens = {}
        for k, (a, b) in spans.items():
            idx = [n0 + i for i, (s, e) in enumerate(tok["offset_mapping"]) if e > a and s < max(b, a + 1)]
            if idx:
                key_tokens[k] = idx
        return {"ids": ids.to(self.device), "grid": pre["image_grid_thw"].to(self.device),
                "key_tokens": key_tokens, "n0": n0}

    def key_logps(self, pix: torch.Tensor, teacher) -> Dict[str, torch.Tensor]:
        """Teacher-forced log p(real value tokens) per key, differentiable wrt `pix`; also returns argmax agreement."""
        ids = teacher["ids"]
        out = self.model(input_ids=ids, attention_mask=torch.ones_like(ids),
                         pixel_values=pix.to(self.model.dtype), image_grid_thw=teacher["grid"])
        n0 = teacher["n0"]
        logits = out.logits[0, n0 - 1: -1].float()
        lp = torch.log_softmax(logits, -1)
        tgt = ids[0, n0:]
        tok_lp = lp.gather(1, tgt[:, None])[:, 0]
        hit = (lp.argmax(-1) == tgt)
        res, agree = {}, {}
        for k, idx in teacher["key_tokens"].items():
            j = [i - n0 for i in idx]
            res[k] = tok_lp[j].sum()
            agree[k] = bool(hit[j].all())
        return res, agree
