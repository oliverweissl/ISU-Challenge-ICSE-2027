# hynea (H1/H2): per-scene HyNeA-style hypernet optimisation (feasibility, n=10)
Run from track_a/solution:
H1: `python -m hynea.optimize --name h1_k2_10 --K 2 --res 256 --steps 100 --check-every 10 --extra 2 --strength 0.5 --vlm-scale 0.5 --lr 5e-5 --lam-fid 3 --device cuda:0`
H2: `python -m hynea.optimize --name h2_k4_10 --ckpt checkpoints/t1_smoke/trunk_000400.pt --res 256 --steps 40 --strength 0.5 --vlm-scale 0.5 --lr 2e-5 --lam-fid 3 --device cuda:1`
Eval: `python evaluator_cli.py evaluate --submission-path submissions/<name> --output track_a_evaluation_output/<name>/report.json --failure-model qwen`; table: `python -m hynea.summarize <names>`.
Traces: out/hynea/<name>/results.json; readings cache readings.json. Loss: fidelity (L1+LPIPS to I1 anchor) + steering (teacher-forced Qwen log p of the real reading's value per still-matching feature, hinge at p<tau).
