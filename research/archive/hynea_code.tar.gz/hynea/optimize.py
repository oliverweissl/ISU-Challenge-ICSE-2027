"""HyNeA-faithful per-scene optimisation of a zero-init control hypernet on Z-Image-Turbo (H1) or from the T1 trunk (H2).

Per scene: sample the (truncated) 8-step Turbo schedule from the noised anchor latent through the frozen backbone + trunk
hypernet, decode with the frozen VAE, loss = fidelity(anchor) + steering(Qwen2.5-VL, teacher-forced real reading),
AdamW + OneCycle, gradient checkpointing, early stop on the evaluator-style Qwen reading.

    python -m hynea.optimize --name h1_k2_10 --K 2 --res 256 --steps 150 --device cuda:0     (run from track_a/solution)
"""
import argparse
import gc
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import torch.utils.checkpoint as ckpt
from PIL import Image

HERE = Path(__file__).resolve().parent
SOL = HERE.parent
TRACK_A = SOL.parent
DATA = TRACK_A.parent / "data"
for p in (str(SOL), str(TRACK_A)):
    if p not in sys.path:
        sys.path.insert(0, p)

from trunk.components import Encoders, base_dir  # noqa: E402
from trunk.config import TrunkConfig  # noqa: E402
from trunk.dataset import ControlTupleDataset, fit_size  # noqa: E402
from trunk.losses import turbo_sigmas  # noqa: E402
from trunk.model import ZImageTrunk  # noqa: E402
from hynea.qwen_diff import DiffQwen  # noqa: E402
from track_a_metrics import public_features, _normalize  # noqa: E402

STEMS = [f"sample_{i:05d}" for i in range(40, 50)]


def vocab_of(stems):
    vocab = {}
    for s in stems:
        for k, v in public_features(json.loads((DATA / "labels" / f"{s}.json").read_text())).items():
            vocab.setdefault(k, set()).add(_normalize(v))
    return vocab


def mismatches(pred, real, keys):
    return [k for k in keys if _normalize(pred.get(k)) != _normalize(real.get(k))]


class Readings:
    """Cache of evaluator-style Qwen readings keyed by (kind, stem); kind real / anchor."""

    def __init__(self, path, dq, vocab):
        self.path, self.dq, self.vocab = Path(path), dq, vocab
        self.d = json.loads(self.path.read_text()) if self.path.exists() else {}

    def get(self, kind, stem, pil):
        key = f"{kind}/{stem}"
        if key not in self.d:
            pred, ans = self.dq.read(pil, self.vocab)
            self.d[key] = {"pred": pred, "answer": ans["answer"]}
            self.path.write_text(json.dumps(self.d, indent=1))
        return self.d[key]


class HyNeA:
    def __init__(self, a, stems):
        self.a, self.dev = a, torch.device(a.device)
        dtype = torch.bfloat16
        self.size = fit_size(960, 540, a.res)
        self.W, self.H = self.size
        self.n_tok = (self.W // 16) * (self.H // 16)
        # encoders; Qwen3 text encoder on CPU only to cache the scene prompts, then dropped
        self.enc = Encoders(a.device, text_device="cpu", dtype=dtype)
        self.ds = ControlTupleDataset.from_data_dir(self.size, stems=stems)
        self.caps = {s: self.enc.encode_prompt([self.ds.records[i]["prompt"]]) for i, s in enumerate(stems)}
        self.enc.text_encoder = None
        self.sig = turbo_sigmas(self.enc.scheduler, self.n_tok, 8)
        self.sig = torch.cat([self.sig, torch.zeros(1)]).tolist()
        self.base = ZImageTrunk.build_base(base_dir(), dtype, a.device)
        self.vocab = vocab_of(stems)
        self.dq = DiffQwen(a.device)
        self.dq.model.gradient_checkpointing_enable()
        self.dq.model.train()  # HF only checkpoints in train mode; Qwen has no dropout
        self.vlm_hw = (self.dq.grid_for(Image.new("RGB", (960, 540)))[0][1] * 14,
                       self.dq.grid_for(Image.new("RGB", (960, 540)))[0][2] * 14)
        if a.vlm_scale != 1.0:
            self.vlm_hw = (int(round(self.vlm_hw[0] * a.vlm_scale / 28)) * 28, int(round(self.vlm_hw[1] * a.vlm_scale / 28)) * 28)
        self.lp = None
        if a.lam_lpips > 0:
            import lpips
            self.lp = lpips.LPIPS(net="vgg", verbose=False).to(self.dev).eval().requires_grad_(False)
        self.state = torch.load(a.ckpt, map_location="cpu") if a.ckpt else None
        self.cfg = TrunkConfig.from_dict(self.state["cfg"]) if self.state else TrunkConfig(n_trunk=a.K).resolved()
        self.out = SOL / "out" / "hynea" / a.name
        self.out.mkdir(parents=True, exist_ok=True)
        self.readings = Readings(self.out / "readings.json", self.dq, self.vocab)

    # ---------------------------------------------------------------------------------------------------
    def new_trunk(self):
        tr = ZImageTrunk(self.base, self.cfg).to(self.dev)
        if self.state:
            tr.load_state_dict(self.state["model"])
        tr.train()
        return tr

    def sample(self, tr, z0, i0, cap, lat, presence, knob):
        z = z0
        for i in range(i0, len(self.sig) - 1):
            s, sn = self.sig[i], self.sig[i + 1]
            tm = torch.tensor([1.0 - s], device=self.dev, dtype=torch.bfloat16)
            out = tr(list(z.to(torch.bfloat16).unsqueeze(2).unbind(0)), tm, cap, control=lat, presence=presence, knob=knob)
            z = z + (sn - s) * (-out.squeeze(2).float())
        return z

    def decode(self, z):
        vae = self.enc.vae
        zz = (z / vae.config.scaling_factor + vae.config.shift_factor).to(torch.bfloat16)
        if torch.is_grad_enabled():
            img = ckpt.checkpoint(lambda t: vae.decode(t, return_dict=False)[0], zz, use_reentrant=False)
        else:
            img = vae.decode(zz, return_dict=False)[0]
        return img.float().clamp(-1, 1)

    def to_pil(self, img):
        arr = ((img[0] + 1) * 127.5).round().clamp(0, 255).byte().permute(1, 2, 0).cpu().numpy()
        return Image.fromarray(arr).resize((960, 540), Image.LANCZOS)

    # ---------------------------------------------------------------------------------------------------
    def run_scene(self, idx, stem):
        a, dev = self.a, self.dev
        item = self.ds[idx]
        real_pil = Image.open(DATA / "real" / f"{stem}_real.jpg").convert("RGB")
        anc_pil = Image.open(TRACK_A / "submissions" / "is_s0.7_60" / "generated" / f"{stem}.png").convert("RGB")
        keys = sorted(public_features(json.loads((DATA / "labels" / f"{stem}.json").read_text())))
        real = self.readings.get("real", stem, real_pil)
        anc = self.readings.get("anchor", stem, anc_pil)
        miss0 = mismatches(anc["pred"], real["pred"], keys)
        target = min(len(keys), len(miss0) + a.extra)
        teacher = self.dq.build_teacher(self.vocab, real["answer"], Image.new("RGB", (self.vlm_hw[1], self.vlm_hw[0])))
        rec = {"stem": stem, "keys": keys, "anchor_mismatch": miss0, "target": target, "trace": []}
        if teacher is None:
            rec["skipped"] = "real reading not parseable"
            return rec, None
        anchor = torch.from_numpy(np.asarray(anc_pil.resize(self.size, Image.LANCZOS), dtype=np.float32) / 127.5 - 1).permute(2, 0, 1)[None].to(dev)
        sim = item["image"][None].to(dev)
        with torch.no_grad():
            x0 = self.enc.encode_image(anchor)
            lat = {m: self.enc.encode_image(item["control"][m][None].to(dev)) for m in self.cfg.modalities}
        presence = torch.ones(1, len(self.cfg.modalities), dtype=torch.bool, device=dev)
        knob = torch.ones(1, device=dev)
        cap = self.caps[stem]
        i0 = int((torch.tensor(self.sig[:7]) - a.strength).abs().argmin())
        g = torch.Generator(device=dev).manual_seed(1000 + idx)
        eps = torch.randn(x0.shape, generator=g, device=dev)
        s0 = self.sig[i0]
        z0 = (1 - s0) * x0 + s0 * eps
        rec["sigma0"] = s0

        tr = self.new_trunk()
        params = [p for p in tr.parameters() if p.requires_grad]
        opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=a.wd)
        sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=a.lr, total_steps=a.steps, pct_start=0.2)
        active = [k for k in keys if k not in miss0]
        torch.cuda.reset_peak_memory_stats(dev)
        torch.cuda.synchronize()
        t_start = time.perf_counter()

        def exact_check():
            with torch.no_grad():
                img = self.decode(self.sample(tr, z0, i0, cap, lat, presence, knob))
            pil = self.to_pil(img)
            pred, ans = self.dq.read(pil, self.vocab)
            return mismatches(pred, real["pred"], keys), pil, pred

        # zero-init equivalence record: step-0 image of the untouched hypernet (H1) / of the loaded trunk (H2)
        tr.eval()
        miss, pil, pred = exact_check()
        tr.train()
        rec["init_mismatch"] = miss
        pil.save(self.out / f"{stem}_init.png")
        best = (len(miss), pil, miss, pred, 0)
        stop = "max_steps"
        if len(miss) >= target:
            stop = "reached_at_init"
        else:
            active = [k for k in keys if k not in miss]
        step = 0
        while stop == "max_steps" and step < a.steps:
            z = self.sample(tr, z0, i0, cap, lat, presence, knob)
            img = self.decode(z)
            l1 = (img - anchor).abs().mean()
            lp = self.lp(img, anchor).mean() if self.lp is not None else torch.zeros((), device=dev)
            lps = self.lp(img, sim).mean() if (self.lp is not None and a.lam_sim > 0) else torch.zeros((), device=dev)
            fid = a.lam_l1 * l1 + a.lam_lpips * lp + a.lam_sim * lps
            pix = self.dq.pixels(((img[0] + 1) / 2), self.vlm_hw)
            lps_k, agree = self.dq.key_logps(pix, teacher)
            terms = [torch.relu(lps_k[k] - float(np.log(a.tau))) for k in active if k in lps_k]
            steer = torch.stack(terms).mean() if terms else torch.zeros((), device=dev)
            loss = a.lam_fid * fid + a.lam_st * steer
            opt.zero_grad(set_to_none=True)
            loss.backward()
            gn = torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            sched.step()
            step += 1
            n_flip = sum(not agree[k] for k in keys if k in agree)
            rec["trace"].append({"step": step, "loss": float(loss), "l1": float(l1), "lpips": float(lp), "steer": float(steer),
                                 "tf_flipped": n_flip, "gnorm": float(gn), "lr": sched.get_last_lr()[0],
                                 "t": time.perf_counter() - t_start})
            if step % a.check_every == 0 or step == a.steps:
                tr.eval()
                miss, pil, pred = exact_check()
                tr.train()
                rec["trace"][-1]["exact_mismatch"] = len(miss)
                if len(miss) > best[0] or (len(miss) == best[0] and False):
                    best = (len(miss), pil, miss, pred, step)
                active = [k for k in keys if k not in miss]
                print(f"  {stem} step {step} loss {float(loss):.3f} l1 {float(l1):.3f} lp {float(lp):.3f} steer {float(steer):.3f} "
                      f"tf_flip {n_flip} exact_mismatch {len(miss)}/{len(keys)} (target {target}) {time.perf_counter() - t_start:.0f}s", flush=True)
                if len(miss) >= target:
                    stop = "reached"
                    break
        torch.cuda.synchronize()
        rec["seconds"] = time.perf_counter() - t_start
        rec["peak_vram_gb"] = torch.cuda.max_memory_allocated(dev) / 2**30
        rec.update(stop=stop, steps_run=step, final_mismatch=best[2], best_step=best[4])
        del tr, opt, sched
        gc.collect()
        torch.cuda.empty_cache()
        return rec, best[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--K", type=int, default=2)
    ap.add_argument("--ckpt", default=None, help="H2: T1 trunk checkpoint (.pt with cfg+model)")
    ap.add_argument("--res", type=int, default=256, help="long side of the optimisation resolution (256 -> 256x144)")
    ap.add_argument("--steps", type=int, default=150)
    ap.add_argument("--lr", type=float, default=5e-5)
    ap.add_argument("--wd", type=float, default=0.0)
    ap.add_argument("--strength", type=float, default=0.7)
    ap.add_argument("--extra", type=int, default=2, help="stop once this many MORE features mismatch than for the anchor")
    ap.add_argument("--check-every", type=int, default=10)
    ap.add_argument("--tau", type=float, default=0.3, help="steer until p(real value) < tau")
    ap.add_argument("--lam-fid", type=float, default=10.0)
    ap.add_argument("--lam-l1", type=float, default=1.0)
    ap.add_argument("--lam-lpips", type=float, default=1.0)
    ap.add_argument("--lam-sim", type=float, default=0.0)
    ap.add_argument("--lam-st", type=float, default=1.0)
    ap.add_argument("--vlm-scale", type=float, default=1.0)
    ap.add_argument("--stems", default=",".join(STEMS))
    ap.add_argument("--device", default="cuda:0")
    a = ap.parse_args()
    stems = a.stems.split(",")
    h = HyNeA(a, STEMS if len(stems) <= len(STEMS) and set(stems) <= set(STEMS) else stems)
    sub = TRACK_A / "submissions" / a.name
    for d in ("simulated", "generated", "reference", "labels"):
        (sub / d).mkdir(parents=True, exist_ok=True)
    for p in sorted((DATA / "real").iterdir()):
        shutil.copy(p, sub / "reference" / p.name)
    allstems = STEMS if set(stems) <= set(STEMS) else stems
    results, total = [], 0.0
    for stem in stems:
        idx = allstems.index(stem)
        rec, pil = h.run_scene(idx, stem)
        results.append(rec)
        if pil is not None:
            pil.save(sub / "generated" / f"{stem}.png")
            shutil.copy(DATA / "images" / f"{stem}_sim.png", sub / "simulated" / f"{stem}_sim.png")
            shutil.copy(DATA / "labels" / f"{stem}.json", sub / "labels" / f"{stem}_label.json")
        total += rec.get("seconds", 0.0)
        print(f"[{stem}] anchor_miss {len(rec['anchor_mismatch'])} init {len(rec.get('init_mismatch', []))} "
              f"final {len(rec.get('final_mismatch', []))} target {rec['target']} stop {rec.get('stop')} "
              f"{rec.get('seconds', 0):.0f}s vram {rec.get('peak_vram_gb', 0):.1f}GB", flush=True)
        (h.out / "results.json").write_text(json.dumps({"args": vars(a), "scenes": results}, indent=1))
    (sub / "generation_times.json").write_text(json.dumps(
        {"total_seconds": total, "scenes": len(results), "hardware": "NVIDIA L40S (shared)"}, indent=2))
    (sub / "config.json").write_text(json.dumps(vars(a), indent=2))


if __name__ == "__main__":
    main()
