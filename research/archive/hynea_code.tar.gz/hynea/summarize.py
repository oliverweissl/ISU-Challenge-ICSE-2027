"""Table of evaluator reports for the hold-out runs + per-feature mismatch counts. python -m hynea.summarize run1 run2 ..."""
import json, sys
from collections import Counter
from pathlib import Path
TA = Path(__file__).resolve().parents[2]
for r in sys.argv[1:]:
    rep = json.load(open(TA / "track_a_evaluation_output" / r / "report.json"))
    f = rep["failure_raw"]; rows = f["images"]
    c = Counter(k for row in rows for k, v in row["feature_matches"].items() if not v)
    tot = sum(len(row["feature_matches"]) for row in rows)
    perscene = [sum(not v for v in row["feature_matches"].values()) for row in rows]
    g = rep["realism_raw"]["generated_vs_real"]
    print(f"{r}: failure {f['failures']}/{f['executed']}  mismatches {sum(c.values())}/{tot}  per-scene {perscene}")
    print("   per-feature", dict(c.most_common()))
    sv = rep["sam"]["simulated_vs_generated"]; print("   sam", {k: round(v, 3) for k, v in sv.items() if isinstance(v, (int, float))})
    print("   realism", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in g.items() if isinstance(v, (int, float))})
